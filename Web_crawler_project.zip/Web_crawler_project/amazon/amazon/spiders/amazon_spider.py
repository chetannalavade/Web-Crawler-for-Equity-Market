import scrapy
from ..items import AmazonItem

class AmazonSpiderSpider(scrapy.Spider):
    name = 'amazon'
    page_number = 2
    start_urls = [
        'https://www.flipkart.com/mobiles/pr?sid=tyy%2C4io&p%5B%5D=facets.brand%255B%255D%3Drealme&p%5B%5D=facets.availability%255B%255D%3DExclude%2BOut%2Bof%2BStock&param=7564&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InRpdGxlIjp7Im11bHRpVmFsdWVkQXR0cmlidXRlIjp7ImtleSI6InRpdGxlIiwiaW5mZXJlbmNlVHlwZSI6IlRJVExFIiwidmFsdWVzIjpbIlNob3AgTm93Il0sInZhbHVlVHlwZSI6Ik1VTFRJX1ZBTFVFRCJ9fX19fQ%3D%3D&otracker=clp_metro_expandable_1_3.metroExpandable.METRO_EXPANDABLE_Shop%2BNow_mobile-phones-store_Q1PDG4YW86MF_wp2&fm=neo%2Fmerchandising&iid=M_1ae81903-2ef9-41a5-84cf-bc7543a65c7a_3.Q1PDG4YW86MF&ppt=clp&ppn=mobile-phones-store&ssid=olb2iyq5340000001663423797056&page=1'
    ]

    def parse(self, response):
        items = AmazonItem()

        # mobiles=response.css('div.mobile')
        #
        # for m in mobiles:
        #     product_name = m.css('._4rR01T::text').extract()
        #     product_author = m.css('.rgWa7D:nth-child(1)').css('::text').extract()
        #     product_price = m.css('._1_WHN1').css('::text').extract()
        #     product_imagelink = m.css('._3exPp9::attr(src)').extract()
        #
        #     items['product_name'] = product_name
        #     items['product_author'] = product_author
        #     items['product_price'] = product_price
        #     items['product_imagelink'] = product_imagelink
        #
        #     yield items

        product_name = response.css('._4rR01T::text').extract()
        product_author = response.css('.rgWa7D:nth-child(1)').css('::text').extract()
        product_price = response.css('._1_WHN1').css('::text').extract()
        product_imagelink = response.css('._3exPp9::attr(src)').extract()

        items['product_name'] = product_name
        items['product_author'] = product_author
        items['product_price'] = product_price
        items['product_imagelink'] = product_imagelink

        yield items

        next_page = 'https://www.flipkart.com/mobiles/pr?sid=tyy%2C4io&p%5B%5D=facets.brand%255B%255D%3Drealme&p%5B%5D=facets.availability%255B%255D%3DExclude%2BOut%2Bof%2BStock&param=7564&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InRpdGxlIjp7Im11bHRpVmFsdWVkQXR0cmlidXRlIjp7ImtleSI6InRpdGxlIiwiaW5mZXJlbmNlVHlwZSI6IlRJVExFIiwidmFsdWVzIjpbIlNob3AgTm93Il0sInZhbHVlVHlwZSI6Ik1VTFRJX1ZBTFVFRCJ9fX19fQ%3D%3D&otracker=clp_metro_expandable_1_3.metroExpandable.METRO_EXPANDABLE_Shop%2BNow_mobile-phones-store_Q1PDG4YW86MF_wp2&fm=neo%2Fmerchandising&iid=M_1ae81903-2ef9-41a5-84cf-bc7543a65c7a_3.Q1PDG4YW86MF&ppt=clp&ppn=mobile-phones-store&ssid=olb2iyq5340000001663423797056&page=' + str(AmazonSpiderSpider.page_number)

        if AmazonSpiderSpider.page_number<5 :
            print(AmazonSpiderSpider.page_number)
            yield response.follow(next_page, callback=self.parse)
            AmazonSpiderSpider.page_number += 1
